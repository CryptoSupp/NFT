1.Unzip the archive
2.Start the bot
3.Install the VC_redist.x86 library
4.Start using
Good luck!